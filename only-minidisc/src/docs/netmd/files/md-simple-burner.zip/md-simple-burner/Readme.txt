
--------------------------------------------------------------------------------------
         MD Simple Burner version 2.0 README File
--------------------------------------------------------------------------------------

Read this document before using MD Simple Burner version 2.0.

[Table Of Contents]
--------------------------------------------------------------------------------------

1) Before using MD Simple Burner
  * System Requirements
  * Installing and Operating MD Simple Burner with Windows XP Media Center Edition 2005 /
    Windows XP Media Center Edition 2004 / Windows XP Media Center Edition /
    Windows XP Professional / Windows XP Home Edition / Windows 2000 Professional
2) Using MD Simple Burner
  * MD Simple Burner Simple Mode and Standard Mode
  * System Suspend / System Idle
  * Running MD Simple Burner with other applications
  * Installation Folder
3) Copyrights and Trademarks

--------------------------------------------------------------------------------------

1) Before using MD Simple Burner

[System Requirements]
 - PC: IBM PC/AT and compatible with pre-installed Windows operating system

 - Windows versions supported:
   Windows XP Media Center Edition 2005 / Windows XP Media Center Edition 2004 /
   Windows XP Media Center Edition / Windows XP Professional / Windows XP Home Edition /
   Windows 2000 Professional / Windows Millennium Edition /
   Windows 98 Second Edition (manufacturer installed)

 - Windows versions NOT supported:
   Windows 95, all versions of Windows 98 not mentioned above, Windows NT and
   all versions of Windows 2000 not mentioned above.

   Important Note: Do not install MD Simple Burner in a dual boot environment.

 - CPU: Pentium II 400MHz (Pentium III 450MHz or higher recommended)
   RAM: 64MB or more (RAM: 128MB or more recommended)

 - Hard Disk: 250MB or more
   Additional space may be required for storing music data.
   More space may be required depending on OS environment.

 - Display: 800 x 600 resolution 
            16-bit High Color or higher
            256 colors or higher required for proper functionality.

 - Sound Card
   Windows XP Media Center Edition 2005 / Windows XP Media Center Edition 2004 /
   Windows XP Media Center Edition / Windows XP Professional / Windows XP Home Edition /
   Windows 2000 Professional / Windows Millennium Edition / Windows 98 Second Edition compatible.

 - Internet connection is required to use CDDB(r).

[Installing and Operating MD Simple Burner with Windows XP Media Center Edition 2005 /
Windows XP Media Center Edition 2004 / Windows XP Media Center Edition / Windows XP Professional /
Windows XP Home Edition / Windows 2000 Professional]

 - Do not use MD Simple Burner with logging on Windows XP Media Center Edition 2005 /
   Windows XP Media Center Edition 2004 / Windows XP Media Center Edition / Windows XP Professional /
   Windows XP Home Edition / Windows 2000 Professional by using Windows domain user account.

 - MD Simple Burner must be installed by Administrator Account Users.
 - MD Simple Burner should be operated by Administrator and Power User Account Users. 
   (When installing MD Simple Burner on Windows XP Home Edition, you should use
    the "Administrators" Account.) 
   It cannot not be used by User Account Users.

---------------------------------------------------------------------------------

2) Using MD Simple Burner

[MD Simple Burner Simple Mode and Standard Mode]
 - OpenMG Jukebox or SonicStage cannot be launched while automatic CD to MD download
   is in progress or while MD Simple Burner is running in Standard Mode.

 - Automatic CD to MD download cannot be executed while OpenMG Jukebox or SonicStage
   is running.
   To use MD Simple Burner, close OpenMG Jukebox or SonicStage and try again. 

 - While starting PC, MD Simple Burner in Simple Mode will be launched as service
   automatically.
   To terminate it, right-click on an icon on the task tray and select Exit from
   a shortcut menu.  

[System Suspend / System Idle]
 - Do not activate System Suspend or System Idle mode while MD Simple Burner software is
   in use.
   Activating System Suspend or System Idle mode in operations such as recording a CD or
   importing a file, the data may be corrupted and the computer may not be able to go out
   of system suspend / system idle mode. 

 - During operation, MD Simple Burner software turns off the System Suspend Timer /
   System Idle Timer based on ACPI. 
   Track your battery indicator when using batteries or connect to an AC power source.

[Running MD Simple Burner with other applications]
 - Some CD player applications may cause conflicts with MD Simple Burner.

 - Some computing-intensive applications may cause intermittent playback.

 - Installing other applications while MD Simple Burner is running may cause problems
   on installation.
   Before installing other applications, right-click on an icon on the task tray and
   select Exit from a shortcut menu.

[Installation Folder]
 - Do not change contents in the installation folder or the music database folder.

 - Do not change the Drive Letter designation of the disk drive, which contains
   the installation folder for the music database folder.

--------------------------------------------------------------------------------

3) Copyrights and Trademarks

  Copyright 2001,2002,2003,2004 Sony Corporation.

  CD and music-related data from Gracenote, Inc.,
  copyright (c) 2000-2003 Gracenote. Gracenote CDDB(R) Client Software,
  copyright 2000-2003 Gracenote. This product and service may practice
  one or more of the following U.S. Patents: #5,987,525; #6,061,680;
  #6,154,773, #6,161,132, #6,230,192, #6,230,207, #6,240,459, #6,330,593,
  and other patents issued or pending.

  Gracenote and CDDB are registered trademarks of Gracenote. The Gracenote
  logo and logotype, the Gracenote CDDB logo, and the "Powered by Gracenote"
  logo are trademarks of Gracenote.

  OpenMG, Hi-MD, Net MD, ATRAC, ATRAC3, ATRAC3plus and their respective logos
  are trademarks of Sony Corporation.

  Other system names and product names appearing herein are generally
  trademarks or registered trademarks of their respective makers. 
  These trademarks are not denoted in this document by means of
  the (TM) or (R) symbols. 

--------------------------------------------------------------------------------
  Readme.txt / Copyright 2001,2002,2003,2004 Sony Corporation.
